const http = require("http");
const crypto = require("crypto");
const { WebSocketServer } = require("ws");
const { normalizeEmail, createEmailUser, authenticateEmail, getUserById, getGoogleUser, createGoogleUser, updateGoogleUser, createSession, resolveSession, revokeSession, publicUser, setPartyIdentity, getAccountPreferences, setQuickReactions, markNotificationsRead } = require("./auth-store");
const scrapbook = require("./scrapbook-store");
const { signHighlightMessage, signHighlightInteraction } = require("./highlight-proof");

// Scrapbook maintenance (purge of removed memories past their 30-day restore
// window, removal-request expiry, ledger compaction): on boot, every 6 hours
// and at most hourly from the Scrapbook list route. A DB lease keeps it to
// one instance at a time. Timers are unref'd so they never hold the process.
let lastScrapbookMaintenanceAt = 0;
function maybeRunScrapbookMaintenance(force = false) {
  if (!force && Date.now() - lastScrapbookMaintenanceAt < 3600000) return;
  lastScrapbookMaintenanceAt = Date.now();
  scrapbook.runMaintenance().catch(e => console.error('[SyncParty Scrapbook maintenance]', e?.message || e));
}
if (process.env.SP_DISABLE_SCRAPBOOK_MAINTENANCE !== "1") {
  setTimeout(() => maybeRunScrapbookMaintenance(true), 30000).unref?.();
  setInterval(() => maybeRunScrapbookMaintenance(true), 6 * 3600000).unref?.();
}
const metadataResolver = require("./metadata-resolver");
const port = Number(process.env.PORT || 8787);

// One live WebSocket per stable clientId. A browser tab keeps clientId in
// sessionStorage, so a reload replaces the previous connection instead of
// creating a second participant.
const rooms = new Map();
const roomTargets = new Map();
const clients = new Map();
const clientSockets = new Map();
const navigationTransitions = new Map();
// One ordered timeline on the existing playback channel.
const roomPlayback = new Map();
let presenceSerial = 0;
const NAV_TRANSITION_TTL_MS = 30000;
const NAV_DISCONNECT_GRACE_MS = 15000;

function json(res, status, body, extra={}) {
  const requestId = res.getHeader?.("X-Request-ID");
  res.writeHead(status, { "Content-Type":"application/json", "Cache-Control":"no-store", "Access-Control-Allow-Origin":"*", "Access-Control-Allow-Headers":"Content-Type, Authorization, X-Request-ID, X-SyncParty-Operation", "Access-Control-Allow-Methods":"GET,POST,OPTIONS", ...(requestId ? { "X-Request-ID": requestId } : {}), ...extra });
  res.end(JSON.stringify(body));
}
async function readJson(req) {
  let raw=""; for await (const chunk of req) raw += chunk; try { return JSON.parse(raw || "{}"); } catch { return {}; }
}
function bearer(req) { return req.headers.authorization || ""; }
async function requireUser(req,res) {
  const user=await resolveSession(bearer(req));
  if(!user){json(res,401,{ok:false,error:"Sign in required."});return null;}
  return user;
}
function isValidPassword(p) { return typeof p === "string" && p.length >= 8 && p.length <= 128; }
function googleConfig() { return { clientId: process.env.GOOGLE_CLIENT_ID || "" }; }

const httpServer = http.createServer(async (req, res) => {
  if (req.method === "OPTIONS") { json(res,204,{}); return; }
  if (req.url === "/health" || req.url === "/") {
    json(res,200,{ ok:true, name:"SyncParty Relay", version:"0.7.1" });
    return;
  }
  if (!req.url.startsWith("/api/")) { json(res,404,{ok:false,error:"Not found"}); return; }

  const suppliedRequestId=String(req.headers["x-request-id"]||"").trim();
  req.spRequestId=/^[A-Za-z0-9._:-]{1,120}$/.test(suppliedRequestId)?suppliedRequestId:crypto.randomUUID();
  res.setHeader("X-Request-ID",req.spRequestId);
  try {
    const u=new URL(req.url,"http://localhost");
    const path=u.pathname;

    if (path === "/api/auth/google/config" && req.method === "GET") {
      json(res,200,{ok:true,...googleConfig()}); return;
    }

    if (path === "/api/auth/signup" && req.method === "POST") {
      const b=await readJson(req); const email=normalizeEmail(b.email);
      if(!email || !email.includes("@")) {json(res,400,{ok:false,error:"Enter a valid email address."});return;}
      if(!isValidPassword(b.password)) {json(res,400,{ok:false,error:"Password must be at least 8 characters."});return;}
      const created=await createEmailUser({email,password:b.password,name:b.name,partyIdentity:b.partyIdentity});
      if(created.error){json(res,409,{ok:false,error:created.error});return;}
      const session=await createSession(created.user.id);
      json(res,200,{ok:true,token:session,user:publicUser(created.user)}); return;
    }

    if (path === "/api/auth/login" && req.method === "POST") {
      const b=await readJson(req); const user=await authenticateEmail(b.email,b.password);
      if(!user){json(res,401,{ok:false,error:"Email or password is incorrect."});return;}
      const session=await createSession(user.id);
      // claimOnly: adopt the guest Party Identity only if this account has
      // never saved one. A returning account keeps the server copy.
      const claimed=b.partyIdentity?await setPartyIdentity(user.id,b.partyIdentity,{claimOnly:true}):user;
      json(res,200,{ok:true,token:session,user:publicUser(claimed||user)}); return;
    }

    if (path === "/api/auth/logout" && req.method === "POST") {
      await revokeSession(bearer(req)); json(res,200,{ok:true}); return;
    }

    if (path === "/api/auth/me" && req.method === "GET") {
      const user=await requireUser(req,res); if(!user)return;
      json(res,200,{ok:true,user:publicUser(user)}); return;
    }

    if (path === "/api/auth/google/exchange" && req.method === "POST") {
      if(!process.env.GOOGLE_CLIENT_ID || !process.env.GOOGLE_CLIENT_SECRET){json(res,503,{ok:false,error:"Google sign-in is not configured on this SyncParty server."});return;}
      const b=await readJson(req); if(!b.code || !b.redirectUri){json(res,400,{ok:false,error:"Missing Google authorization data."});return;}
      const tokenResp=await fetch("https://oauth2.googleapis.com/token",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:new URLSearchParams({code:b.code,client_id:process.env.GOOGLE_CLIENT_ID,client_secret:process.env.GOOGLE_CLIENT_SECRET,redirect_uri:b.redirectUri,grant_type:"authorization_code"})});
      if(!tokenResp.ok){json(res,401,{ok:false,error:"Google authorization could not be completed."});return;}
      const gt=await tokenResp.json(); const infoResp=await fetch("https://openidconnect.googleapis.com/v1/userinfo",{headers:{Authorization:`Bearer ${gt.access_token}`}});
      if(!infoResp.ok){json(res,401,{ok:false,error:"Google profile could not be read."});return;}
      const info=await infoResp.json(); let user=await getGoogleUser(info.sub);
      if(!user){
        const created=await createGoogleUser({sub:info.sub,email:info.email,name:info.name,partyIdentity:b.partyIdentity});
        user=created.user;
      } else {
        // Google refresh updates account identity only; Party Identity is
        // claimed separately and never overwritten by the Google name.
        user=await updateGoogleUser(user.id,{email:info.email,name:info.name});
        if(b.partyIdentity) user=await setPartyIdentity(user.id,b.partyIdentity,{claimOnly:true})||user;
      }
      const session=await createSession(user.id);
      json(res,200,{ok:true,token:session,user:publicUser(user)}); return;
    }

    // Party Identity: read the account's current Party Name/PFP/color, or save
    // a change. Google Name/Email are never writable here.
    if (path === "/api/account/identity" && req.method === "GET") {
      const user=await requireUser(req,res); if(!user)return;
      json(res,200,{ok:true,user:publicUser(user)}); return;
    }

    if (path === "/api/account/identity" && req.method === "POST") {
      const user=await requireUser(req,res); if(!user)return; const b=await readJson(req);
      const identity={partyName:b.partyName,partyAvatar:b.partyAvatar,partyColor:b.partyColor};
      if(!b.claimOnly && !String(identity.partyName||"").trim()){json(res,400,{ok:false,error:"Party Name is required."});return;}
      const updated=await setPartyIdentity(user.id,identity,{claimOnly:!!b.claimOnly});
      json(res,200,{ok:true,user:publicUser(updated||user)}); return;
    }

    // Account preferences (owner-only): quick-reaction tray + Activity read
    // state. One GET loads both; each write is a single small request.
    if (path === "/api/account/preferences" && req.method === "GET") {
      const user=await requireUser(req,res); if(!user)return;
      json(res,200,{ok:true,...(await getAccountPreferences(user.id))}); return;
    }
    if (path === "/api/account/quick-reactions" && req.method === "POST") {
      const user=await requireUser(req,res); if(!user)return; const b=await readJson(req);
      if(!Array.isArray(b.quickReactions)){json(res,400,{ok:false,error:"quickReactions must be a list."});return;}
      const saved=await setQuickReactions(user.id,b.quickReactions);
      if(!saved){json(res,404,{ok:false,error:"Account not found."});return;}
      json(res,200,{ok:true,...saved}); return;
    }
    if (path === "/api/account/notifications/read" && req.method === "POST") {
      const user=await requireUser(req,res); if(!user)return; const b=await readJson(req);
      json(res,200,{ok:true,...(await markNotificationsRead(user.id,b.ids))}); return;
    }

    if (path === "/api/scrapbook/resolver-check" && req.method === "GET") {
      // Open this URL in a browser to see whether artwork/identity lookups can work at all.
      const configured=!!process.env.TMDB_API_TOKEN; let tmdbStatus=null,error=null;
      if(configured){try{const r=await fetch("https://api.themoviedb.org/3/configuration",{headers:{Authorization:"Bearer "+process.env.TMDB_API_TOKEN}});tmdbStatus=r.status;}catch(e){error=e?.message||String(e);}}
      json(res,200,{ok:configured&&tmdbStatus===200,configured,tmdbStatus,error}); return;
    }

    if (path === "/api/scrapbook/resolve" && req.method === "POST") {
      const b = await readJson(req);
      const meta = b.meta && typeof b.meta === "object" ? b.meta : {};
      const provisional = b.provisional && typeof b.provisional === "object" ? b.provisional : {};
      if (!process.env.TMDB_API_TOKEN) { json(res,503,{ok:false,error:"Metadata resolver is not configured."}); return; }
      const resolved = await metadataResolver.resolve({ meta, provisional });
      json(res,200,{ok:true,metadata:resolved});
      return;
    }

    if (path === "/api/scrapbook" && req.method === "GET") {
      const user=await requireUser(req,res); if(!user)return;
      const scope=u.searchParams.get("scope")==="shared"?"shared":"personal";
      const relationId=u.searchParams.get("relationId")||null;
      const limit=Math.min(300,Math.max(1,Number(u.searchParams.get("limit")||150)));
      // Archived memories stay viewable (read-only) when explicitly requested.
      const includeArchived=u.searchParams.get("includeArchived")!=="0";
      maybeRunScrapbookMaintenance();
      const relationsPromise=scope==='personal'&&u.searchParams.get('includeRelations')==='0'?Promise.resolve([]):scrapbook.listUserRelations(user.id);
      // Scrapbook V2 is the only storage model: Our Story = one shared memory
      // per chapter journey, My Scrapbook = the caller's personal V2 rows.
      const flag=k=>u.searchParams.get(k)==="1";
      if(scope==='shared'){
        const [r,relations]=await Promise.all([scrapbook.listSharedV2(user.id,{chapterId:u.searchParams.get("chapterId")||null,relationId,includeHidden:flag("includeHidden"),includeRemoved:flag("includeRemoved")}),relationsPromise]);
        json(res,200,{ok:true,scope,entries:r.entries.slice(0,limit),relations,chapter:r.chapter,chapters:r.chapters}); return;
      }
      const [entries,relations]=await Promise.all([scrapbook.listPersonalV2(user.id,{limit,includeArchived,includeRemoved:flag("includeRemoved")}),relationsPromise]);
      json(res,200,{ok:true,scope,entries,relations}); return;
    }

    if(path==='/api/scrapbook/artwork/recover'&&req.method==='POST'){
      const user=await requireUser(req,res);if(!user)return;
      const b=await readJson(req);
      const r=await scrapbook.recoverArtwork(user.id,b);
      json(res,r.status||200,r);return;
    }
    if(path==='/api/scrapbook/artwork/incomplete'&&req.method==='GET'){
      const user=await requireUser(req,res);if(!user)return;
      json(res,200,await scrapbook.incompleteArtwork(user.id,{
        personalAfter:u.searchParams.get('personalAfter')||'',sharedAfter:u.searchParams.get('sharedAfter')||''}));
      return;
    }

    if (path === "/api/scrapbook/entries" && req.method === "POST") {
      const user=await requireUser(req,res); if(!user)return; const b=await readJson(req);
      let relation=null;
      if(!b.entry||typeof b.entry!=='object'||Array.isArray(b.entry)||!String(b.entry.sourceKey||'').trim()){
        json(res,400,{ok:false,persisted:false,error:'A valid Scrapbook memory identity is required.',requestId:req.spRequestId});return;
      }
      if(b.scope==='shared'){
        // The client sends the RELATION id, so it has to be looked up by id.
        // getRelation() takes two USER ids, so it never matched and every
        // shared save was rejected with 409 - the watch was then only kept in
        // the personal scope. Fall back to the caller's one active story when
        // no id is supplied.
        relation=b.relationId?await scrapbook.getRelationById(b.relationId):await scrapbook.getActiveRelationRow(user.id);
        if(!relation?.accepted_at||relation.archived_at!=null||relation.ended_at!=null){json(res,409,{ok:false,error:"Shared Scrapbook is not active."});return;}
        const ids=[relation.user1_id,relation.user2_id];
        if(!ids.includes(user.id)){json(res,403,{ok:false,error:"You are not part of this Shared Scrapbook."});return;}
      }
      // One shared memory per chapter journey: a direct shared save (manual
      // /keep, older clients) only ever updates the CALLER's member totals in
      // V2 storage - never a copy per partner, never a personal duplicate.
      const created=[await scrapbook.upsertEntry(user.id,b.entry,b.scope==='shared'?relation.id:null)];
      const saved=created[0]||null;
      if(!saved){
        console.error('[SyncParty Scrapbook keep]',{requestId:req.spRequestId,operation:'entry-save',scope:b.scope==='shared'?'shared':'personal',sourceKey:String(b.entry.sourceKey).slice(0,180),httpStatus:503,persisted:false,code:'EMPTY_WRITE_RESULT'});
        json(res,503,{ok:false,persisted:false,retryable:true,error:'The server did not confirm that this memory was saved.',requestId:req.spRequestId});return;
      }
      console.info('[SyncParty Scrapbook keep]',{
        requestId:req.spRequestId,operation:'entry-save',scope:b.scope==='shared'?'shared':'personal',httpStatus:200,
        sourceKey:String(b.entry?.sourceKey||'').slice(0,180),contentType:String(b.entry?.contentType||b.entry?.kind||'').slice(0,24),
        metadataProvider:String(b.entry?.metadataProvider||'').slice(0,32),metadataId:String(b.entry?.metadataId||'').slice(0,64),
        season:b.entry?.season??null,episode:b.entry?.episode??null,persisted:!!saved,recordId:saved?.id||null
      });
      json(res,200,{ok:true,persisted:!!saved,requestId:req.spRequestId,entries:created}); return;
    }

    if (path === "/api/scrapbook/entries/bulk" && req.method === "POST") {
      const user=await requireUser(req,res); if(!user)return; const b=await readJson(req);
      // One bad record must never sink the whole batch (or the migration that
      // sent it): every entry is isolated, and the reply says exactly which
      // entries were stored and which were not.
      const all=Array.isArray(b.entries)?b.entries:[];
      const entries=all.slice(0,500);
      const out=[]; const failed=[];
      for(const e of entries){
        const key=e&&typeof e==='object'?String(e.sourceKey||''):'';
        try{
          // Backed-up sitting saves keep their server-decided destination.
          if(e&&e.sitting&&typeof e.sitting==='object'){
            const r=await scrapbook.saveSitting(user.id,{...e.sitting,entry:e});
            if(r.ok){out.push({sourceKey:key,sitting:r});continue;}
            failed.push({sourceKey:key,error:r.error||'Could not store entry.'});continue;
          }
          const saved=await scrapbook.upsertEntry(user.id,e,null);
          if(saved) out.push(saved); else failed.push({sourceKey:key,error:'Malformed entry.'});
        }catch(err){
          console.error('[SyncParty Scrapbook bulk]',key,err?.message||err);
          failed.push({sourceKey:key,error:err?.message||'Could not store entry.'});
        }
      }
      json(res,200,{ok:true,entries:out,failed,skipped:Math.max(0,all.length-entries.length)}); return;
    }

    if (path === "/api/scrapbook/relationship" && req.method === "GET") {
      const user=await requireUser(req,res); if(!user)return; const partnerId=u.searchParams.get('partnerId');
      const relation=partnerId?await scrapbook.getRelation(user.id,partnerId):null;
      // The caller's OWN active story is reported whether or not a partnerId
      // was supplied. Without this the sidebar could not tell an ended story
      // from a live one when no partner was in the room, so the badge and the
      // "one active story" promo guard both went stale after ending a story.
      const activeRow=await scrapbook.getActiveRelationRow(user.id);
      const invites=await scrapbook.listInvites(user.id);
      // The PARTNER's active story is reported too. Without it the client
      // could only see its own state, so it happily offered "Start Our Story"
      // to someone who already had one - and the invite was then rejected
      // with a 409 the user never asked for. Same rule, evaluated early.
      const partnerActiveRow=partnerId?await scrapbook.getActiveRelationRow(partnerId):null;
      json(res,200,{
        ok:true,
        relation:await scrapbook.relationView(relation),
        activeRelation:await scrapbook.relationView(activeRow),
        partnerActiveRelation:await scrapbook.relationView(partnerActiveRow),
        relations:await scrapbook.listUserRelations(user.id),
        ...invites
      }); return;
    }

    if (path === "/api/scrapbook/relationship/invite" && req.method === "POST") {
      const user=await requireUser(req,res); if(!user)return; const b=await readJson(req); const partner=await scrapbook.getUser(b.partnerId);
      if(!partner||partner.id===user.id){json(res,400,{ok:false,error:'Choose a valid partner account.'});return;}
      // Only ONE active Our Story per user: block third-party invitations
      // while either side already has an active relationship.
      const [mineActive,theirsActive]=await Promise.all([scrapbook.getActiveRelationRow(user.id),scrapbook.getActiveRelationRow(partner.id)]);
      if(mineActive&&![mineActive.user1_id,mineActive.user2_id].includes(partner.id)){json(res,409,{ok:false,error:'You already have an active Our Story. End it before starting a new one.'});return;}
      if(theirsActive&&![theirsActive.user1_id,theirsActive.user2_id].includes(user.id)){json(res,409,{ok:false,error:'That account already has an active Our Story.'});return;}
      const result=await scrapbook.createInvite(user.id,partner.id);
      if(result.relation){json(res,200,{ok:true,relation:result.relation});return;}
      json(res,200,{ok:true,invite:result.invite});return;
    }

    if (path === "/api/scrapbook/relationship/respond" && req.method === "POST") {
      const user=await requireUser(req,res); if(!user)return; const b=await readJson(req);
      const result=await scrapbook.respondInvite(b.inviteId,user.id,!!b.accept);
      if(result.error){json(res,404,{ok:false,error:result.error});return;}
      json(res,200,{ok:true,relation:result.relation});return;
    }

    // Confirms which locally held memories the server actually has, so the
    // Sync & Backup panel reports real state. Read-only.
    if (path === "/api/scrapbook/reconcile" && req.method === "POST") {
      const user=await requireUser(req,res); if(!user)return; const b=await readJson(req);
      const result=await scrapbook.reconcileEntries(user.id,b.entries);
      json(res,200,{ok:true,...result}); return;
    }

    // Ending or archiving an Our Story is non-destructive: shared memories are
    // kept and the story stays viewable read-only. Personal memories are never
    // touched, and the user may start a new Our Story afterwards.
    if ((path === "/api/scrapbook/relationship/end" || path === "/api/scrapbook/relationship/archive") && req.method === "POST") {
      const user=await requireUser(req,res); if(!user)return; const b=await readJson(req);
      const mode=path.endsWith("/archive")?"archive":"end";
      const relationId=b.relationId||(await scrapbook.getActiveRelationRow(user.id))?.id;
      if(!relationId){json(res,404,{ok:false,error:"You do not have an active Our Story."});return;}
      const result=await scrapbook.closeRelation(relationId,user.id,mode);
      if(result.error){json(res,404,{ok:false,error:result.error});return;}
      json(res,200,{ok:true,relation:result.relation}); return;
    }

    // Reopening an archived/ended story is the inverse of ending it, and is
    // refused when either side already has a different active story.
    if ((path === "/api/scrapbook/relationship/unarchive" || path === "/api/scrapbook/relationship/reopen") && req.method === "POST") {
      const user=await requireUser(req,res); if(!user)return; const b=await readJson(req);
      if(!b.relationId){json(res,400,{ok:false,error:"Choose a story to reopen."});return;}
      const result=await scrapbook.reopenRelation(b.relationId,user.id);
      if(result.error){json(res,409,{ok:false,error:result.error});return;}
      json(res,200,{ok:true,relation:result.relation}); return;
    }

    if (path === "/api/scrapbook/entries/archive" && req.method === "POST") {
      const user=await requireUser(req,res); if(!user)return; const b=await readJson(req);
      const result=await scrapbook.setEntriesArchived(user.id,b.entryIds,!!b.archived);
      json(res,200,{ok:true,...result}); return;
    }

    if (path === "/api/scrapbook/entries/remove" && req.method === "POST") {
      const user=await requireUser(req,res); if(!user)return; const b=await readJson(req);
      const result=await scrapbook.removeEntries(user.id,b.entryIds);
      json(res,200,{ok:true,...result}); return;
    }

    if (path.startsWith("/api/scrapbook/sittings/") && req.method === "POST") {
      const user=await requireUser(req,res); if(!user)return; const b=await readJson(req);
      const kind=path.slice("/api/scrapbook/sittings/".length);
      const r=kind==="intent"?await scrapbook.recordIntent(user.id,{sittingId:b.sittingId,sourceKey:b.sourceKey,roomId:b.roomId||null,playing:!!b.playing})
        :kind==="decide"?await scrapbook.decideSitting(user.id,{sittingId:b.sittingId,sourceKey:b.sourceKey,roomId:b.roomId||null})
        :kind==="save"?await scrapbook.saveSitting(user.id,b):{status:404,error:'Not found'};
      if(r.error){json(res,r.status||400,{ok:false,error:r.error,requestId:req.spRequestId});return;}
      if(kind==='save') {
        const persisted=scrapbook.wasSittingSavePersisted(r);
        console.info('[SyncParty Scrapbook keep]',{
          requestId:req.spRequestId,operation:'sitting-save',httpStatus:persisted?200:409,sittingId:String(b.sittingId||'').slice(0,80),
          sourceKey:String(b.entry?.sourceKey||'').slice(0,180),sequence:Number(b.seq)||0,
          destination:r.decision?.destination||r.target?.destination||null,targetId:r.target?.id||null,
          persisted,duplicate:!!r.duplicate,ignored:r.ignored||null
        });
        if(!persisted){
          json(res,409,{ok:false,persisted:false,error:r.ignored?`This save was not written (${String(r.ignored).slice(0,48)}).`:'The server could not confirm that this memory was saved.',ignored:r.ignored||null,requestId:req.spRequestId});return;
        }
        json(res,200,{ok:true,...r,persisted:true,requestId:req.spRequestId});return;
      }
      json(res,200,{ok:true,...r}); return;
    }

    if (path === "/api/scrapbook/journeys/action" && req.method === "POST") {
      const user=await requireUser(req,res); if(!user)return; const b=await readJson(req);
      const r=await scrapbook.journeyAction(user.id,b);
      if(r.error){json(res,r.status||400,{ok:false,error:r.error,readOnly:!!r.readOnly,blockedUntil:r.blockedUntil||null});return;}
      json(res,200,{ok:true,...r}); return;
    }

    // Compatibility handshake for already-installed extensions: V2 is the only
    // Scrapbook architecture, so this always answers sharedV2:true.
    if (path === "/api/scrapbook/capabilities" && req.method === "GET") {
      json(res,200,{ok:true,sharedV2:true}); return;
    }

    if (path === "/api/scrapbook/chapters" && req.method === "GET") {
      const user=await requireUser(req,res); if(!user)return;
      json(res,200,{ok:true,chapters:await scrapbook.chaptersForUser(user.id)}); return;
    }

    if (path === "/api/scrapbook/moments" && req.method === "GET") {
      const user=await requireUser(req,res); if(!user)return;
      json(res,200,{ok:true,moments:await scrapbook.buildMoments(user.id)}); return;
    }

    if (path === "/api/scrapbook/moments/seen" && req.method === "POST") {
      const user=await requireUser(req,res); if(!user)return; const b=await readJson(req);
      json(res,200,await scrapbook.markMomentsSeen(user.id,b.momentIds)); return;
    }

    // Scene Highlights are distinct from the legacy /highlights summary above.
    // The /records path lists actual private/shared capture records; every query
    // is scoped by the authenticated owner or their existing relation rows.
    if (path === "/api/scrapbook/highlights/records" && req.method === "GET") {
      const user=await requireUser(req,res); if(!user)return;
      const scope=u.searchParams.get("scope")==="shared"?"shared":"personal";
      json(res,200,{ok:true,highlights:await scrapbook.listHighlights(user.id,scope)});return;
    }
    if (path === "/api/scrapbook/highlights" && req.method === "POST") {
      const user=await requireUser(req,res); if(!user)return; const b=await readJson(req);
      const result=await scrapbook.createHighlight(user.id,b.highlight||b);
      json(res,200,{ok:true,persisted:true,duplicate:!!result.duplicate,highlight:result.highlight});return;
    }
    if (path === "/api/scrapbook/highlights/share" && req.method === "POST") {
      const user=await requireUser(req,res); if(!user)return; const b=await readJson(req);
      const result=await scrapbook.shareHighlight(user.id,b.highlightId);
      if(result.error){json(res,result.status||400,{ok:false,error:result.error});return;}
      json(res,200,{ok:true,...result});return;
    }
    if (path === "/api/scrapbook/highlights/remove" && req.method === "POST") {
      const user=await requireUser(req,res); if(!user)return; const b=await readJson(req);
      json(res,200,{ok:true,...await scrapbook.removeHighlight(user.id,b.highlightId)});return;
    }
    if (path === "/api/scrapbook/highlights" && req.method === "GET") {
      const user=await requireUser(req,res); if(!user)return;
      json(res,200,{ok:true,highlights:await scrapbook.getHighlights(user.id)});return;
    }

    json(res,404,{ok:false,error:'Not found'});
  } catch (e) {
    // Preserve the request ID and effective HTTP result in the sanitized log
    // so a client retry can be correlated with a committed/failed write.
    const httpStatus = e && ['SP_LOCK_TIMEOUT','SP_FENCED','SP_SCHEMA_MISSING'].includes(e.code) ? 503
      : e && ['SPV01','SPC01','SPR01'].includes(e.code) ? 409
      : Number.isInteger(e?.status) && e.status >= 400 && e.status < 500 ? e.status : 500;
    console.error('[SyncParty Scrapbook API]',{
      requestId:req.spRequestId||null,operation:`${req.method} ${String(req.url||'').split('?')[0]}`,httpStatus,
      code:String(e?.code||e?.status||'INTERNAL').slice(0,60),
      message:String(e?.message||'SyncParty server error.').slice(0,240),
      detail:String(e?.details||'').slice(0,240)
    });
    // Scrapbook v2: a lock wait that timed out, a lock that moved to another
    // server (fenced) or missing 9.7/9.8 functions are retryable 503s; a
    // transition the database refused (SPV01/SPC01/SPR01) is a 409. Store-level
    // validation/consent failures retain their explicit 4xx status.
    if (httpStatus === 503) { json(res,503,{ok:false,error:e.message,retryable:true,requestId:req.spRequestId}); return; }
    if (httpStatus === 409) { json(res,409,{ok:false,error:'This Scrapbook change is no longer possible; refresh and try again.',requestId:req.spRequestId}); return; }
    const message = process.env.NODE_ENV === 'production' ? 'SyncParty server error.' : (e?.message || 'SyncParty server error.');
    json(res,500,{ok:false,error:message,requestId:req.spRequestId});
  }
});

const wss = new WebSocketServer({ server: httpServer });

function norm(s) { return String(s || "").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 6); }
function randId() { return Math.random().toString(36).slice(2, 10); }
function send(ws, o) { if (ws.readyState === 1) ws.send(JSON.stringify(o)); }
function broadcast(room, o, skip = null) {
  const set = rooms.get(room); if (!set) return;
  for (const ws of set) if (ws !== skip) send(ws, o);
}
function sanitizeProfile(p) {
  return {
    accountId: p?.accountId ? String(p.accountId).slice(0, 128) : null,
    name: String(p?.name || "Guest").slice(0, 24),
    avatar: String(p?.avatar || "🙂").slice(0, 4),
    color: String(p?.color || "#54a0ff").slice(0, 16)
  };
}
function normalizeUrl(raw) {
  try {
    const u = new URL(String(raw || ""));
    if (u.protocol !== "http:" && u.protocol !== "https:") return null;
    u.searchParams.delete("spRoom");
    return u.toString();
  } catch { return null; }
}
function activeTransition(room) {
  const t = navigationTransitions.get(room);
  if (!t) return null;
  if (Date.now() > t.expiresAt) {
    navigationTransitions.delete(room);
    return null;
  }
  return t;
}
function transitionPeerRecord(s) {
  return {
    id: s.clientId || s.id,
    accountId: s.profile?.accountId || null,
    name: s.profile?.name || "Guest",
    avatar: s.profile?.avatar || "🙂",
    color: s.profile?.color || "#54a0ff",
    highlightConsent: s.highlightConsent === true
  };
}
// --- presence grace ----------------------------------------------------------
// A socket closing is a NETWORK event, not a person leaving. The relay used to
// announce "left" on every close and "joined" on every rejoin, so a Wi-Fi blip,
// a tab reload, a duplicate/replaced socket or a relay restart all showed up in
// chat as fake departures/arrivals. A dropped member is now "reconnecting" for
// PRESENCE_GRACE_MS; only if they do not return is "left" announced.
const PRESENCE_GRACE_MS = Number(process.env.SP_PRESENCE_GRACE_MS) || 15000;
const RECENT_MEMBER_MS = Number(process.env.SP_RECENT_MEMBER_MS) || 120000;
const pendingDepartures = new Map(); // `${room}|${clientId}` -> { timer, record, room, id }
const recentMembers = new Map();     // `${room}|${clientId}` -> at (room emptied by a drop)
function rememberMember(room, id) { if (room && id) recentMembers.set(`${room}|${id}`, Date.now()); }
function forgetMember(room, id) { recentMembers.delete(`${room}|${id}`); }
function wasRecentMember(room, id) {
  const at = recentMembers.get(`${room}|${id}`);
  if (!at) return false;
  recentMembers.delete(`${room}|${id}`);
  return Date.now() - at < RECENT_MEMBER_MS;
}
function clearPendingDeparture(room, id) {
  const key = `${room}|${id}`;
  const d = pendingDepartures.get(key);
  if (!d) return false;
  clearTimeout(d.timer);
  pendingDepartures.delete(key);
  return true;
}
function presenceNotice(room, id, name, event, skip = null) {
  const label = event === "joined" ? "Joined" : event === "left" ? "Left the room" : "Disconnected";
  broadcast(room, { type: "message", payload: { kind: "system", presenceEvent: event, id,
    eventId: `presence_${Date.now()}_${++presenceSerial}`, text: `${name} ${label}`, t: Date.now() } }, skip);
}
function announceLeft(room, id, name, event = "left") {
  if (!rooms.get(room)?.size) return;
  broadcast(room, { type: "message", payload: { kind: "peer-connection", state: event, id, name, t: Date.now() } });
  presenceNotice(room, id, name, event);
}
function startDeparture(room, id, s, navigation = false) {
  const key = `${room}|${id}`;
  if (pendingDepartures.has(key)) return;
  const record = { ...transitionPeerRecord(s), reconnecting: true };
  const timer = setTimeout(() => {
    if (pendingDepartures.get(key)?.timer !== timer) return;
    pendingDepartures.delete(key);
    rememberMember(room,id);
    releasePlaybackHold(room,id);
    cleanupTransitionParticipant(room,id);
    broadcastPeers(room);
    announceLeft(room, id, record.name,"disconnected");
  }, navigation ? NAV_DISCONNECT_GRACE_MS : PRESENCE_GRACE_MS);
  if (timer.unref) timer.unref();
  pendingDepartures.set(key, { timer, record, room, id });
  // Expected page navigation already has a playback barrier. It is not a
  // network-loss notification, but it still needs cancellable member cleanup.
  if (!navigation) {
    holdPlayback(room,id,"connection",record.name);
    broadcast(room, { type: "message", payload: { kind: "peer-connection", state: "reconnecting", id, name: record.name, t: Date.now() } });
  }
}
function clearRoomDepartures(room, remember) {
  for (const [key, d] of [...pendingDepartures]) {
    if (d.room !== room) continue;
    clearTimeout(d.timer);
    pendingDepartures.delete(key);
    if (remember) rememberMember(room, d.id);
  }
}

function broadcastPeers(room) {
  const set = rooms.get(room); if (!set) return;
  const t = activeTransition(room);
  const byId = new Map();
  for (const ws of set) {
    const s = clients.get(ws);
    if (!s || s.room !== room || ws.readyState !== 1 || clientSockets.get(s.clientId) !== ws) continue;
    byId.set(s.clientId || s.id, { ...transitionPeerRecord(s), connected: true, reconnecting: false });
  }
  for (const d of pendingDepartures.values()) {
    if (d.room === room && !byId.has(d.id)) byId.set(d.id, { ...d.record, connected: false, reconnecting: true });
  }
  if (t) {
    for (const [id, meta] of t.participants) if (!byId.has(id)) byId.set(id, { ...meta, id, connected: false, reconnecting: true });
  }
  const peers = [...byId.values()];
  broadcast(room, { type: "peers", peers, count: peers.filter(peer => peer.connected).length, memberCount: peers.length });
}
// Commands advance revision; snapshots advance sequence. A follower's
// heartbeat cannot take over the timeline or undo a play/pause/seek intent.
function playbackClock() { return Number(process.hrtime.bigint())/1000000; }
function playbackFor(room, enable = false) {
  let x = roomPlayback.get(room);
  if (!x && enable) {
    x = { epoch:`room_${Date.now()}_${randId()}`, revision:0, sequence:0,
      time:0, at:playbackClock(), rate:1, playing:false, initialized:false,
      controller:null, controllerAt:0, holds:new Map(), idleTimer:null };
    roomPlayback.set(room,x);
  }
  return x;
}
function playbackPosition(x) {
  return x.time + (x.playing ? Math.max(0,playbackClock()-x.at)/1000*x.rate : 0);
}
function playbackPacket(room,event="heartbeat") {
  const x=playbackFor(room); if(!x)return null;
  return { kind:"sync",event,authoritative:true,commandAcks:true,roomEpoch:x.epoch,
    revision:x.revision,sequence:++x.sequence,controllerId:x.controller,
    ...(x.initialized ? {time:playbackPosition(x)} : {}),playing:x.playing,
    rate:x.rate,sentAt:Date.now(),serverSentAt:Date.now(),pageKey:"",
    holds:[...x.holds].map(([id,h])=>({id,name:h.name,reasons:[...h.reasons]})) };
}
function publishPlayback(room,event="heartbeat",ws=null,observer=null,ack=null) {
  const payload=playbackPacket(room,event); if(!payload)return;
  payload.id=observer?.clientId || "__relay__";
  if(observer)payload.observerPlaying=payload.playing;
  if(ack)payload.ack=ack;
  if(ws)send(ws,{type:"message",payload}); else broadcast(room,{type:"message",payload});
}
function freezePlayback(x) {
  x.time=playbackPosition(x); x.at=playbackClock(); x.playing=false;
}
function holdPlayback(room,id,reason,name) {
  const x=playbackFor(room); if(!x)return;
  let h=x.holds.get(id); if(h?.reasons.has(reason))return;
  const wasPlaying=x.playing; freezePlayback(x);
  if(!h){h={name:name||"A viewer",reasons:new Set()};x.holds.set(id,h);}
  h.reasons.add(reason); x.revision++; publishPlayback(room,"hold");
  if(reason!=="connection")broadcast(room,{type:"message",payload:{kind:"system",
    text:`${h.name} ${reason==="suspended"?"is suspended":reason==="autoplay"?"needs to allow playback":reason==="loading"?"is loading the player":"is buffering"}${wasPlaying?" — playback paused for everyone.":". Waiting for recovery."}`}});
}
function releasePlaybackHold(room,id,reason=null) {
  const x=playbackFor(room),h=x?.holds.get(id); if(!h)return;
  if(reason)h.reasons.delete(reason);else h.reasons.clear();
  if(h.reasons.size)return;
  x.holds.delete(id);x.revision++;x.at=playbackClock();
  // Recovery never auto-resumes. One fresh play intent after all blockers
  // clear is safer than autoplay/pause oscillation across different engines.
  publishPlayback(room,"recovery");
  if(!x.holds.size)broadcast(room,{type:"message",payload:{kind:"system",
    text:"Everyone remaining is ready — press Play to resume together."}});
  // Readiness may have arrived before the final health-clear packet. Recheck
  // the existing navigation barrier so that ordering cannot strand the room.
  maybeReleaseTransition(room);
}
function handlePlaybackMessage(ws,s,p) {
  const x=playbackFor(s.room); if(!x)return false;
  if(p.kind==="buffering"){
    const healthSeq=Number(p.healthSeq);
    if(Number.isFinite(healthSeq)){
      if(healthSeq<=(s.lastHealthSeq||0))return true;
      s.lastHealthSeq=healthSeq;
    }
    const reason=["suspended","autoplay"].includes(p.reason)?p.reason:"buffering";
    if(p.active!==false)holdPlayback(s.room,s.clientId,reason,s.profile?.name);
    else releasePlaybackHold(s.room,s.clientId);
    return true;
  }
  if(p.kind!=="sync")return false;
  const reply=(accepted,reason,event="resync",all=false)=>{
    const ack=p.commandId ? {commandId:String(p.commandId),clientId:s.clientId,
      event:String(p.event),accepted,reason} : null;
    publishPlayback(s.room,event,all?null:ws,all?s:null,ack);
    if(p.commandId&&accepted&&reason==="applied"&&["play","pause","seeking","seeked"].includes(event)){
      const seconds=Math.max(0,Math.floor(playbackPosition(x)));
      const hours=Math.floor(seconds/3600),minutes=Math.floor((seconds%3600)/60),remainder=seconds%60;
      const position=hours>0?`${hours}:${String(minutes).padStart(2,"0")}:${String(remainder).padStart(2,"0")}`:
        `${minutes}:${String(remainder).padStart(2,"0")}`;
      const action=event==="play"?"resumed the video":event==="pause"?"paused the video":`jumped to ${position}`;
      broadcast(s.room,{type:"message",payload:{kind:"system",eventId:`playback_${String(p.commandId)}`,
        text:`${s.profile?.name||"A viewer"} ${action}`}});
    }
  };
  const seq=Number(p.syncSeq);
  if(Number.isFinite(seq)){if(seq<=(s.lastSyncSeq||0)){reply(false,"out-of-order");return true;}s.lastSyncSeq=seq;}
  if(p.roomEpoch&&p.roomEpoch!==x.epoch){reply(false,"old-room");return true;}
  const event=String(p.event||"heartbeat");
  if(!["heartbeat","resync","play","pause","seeking","seeked","ratechange"].includes(event))return true;
  const transition=activeTransition(s.room);
  if(transition&&!transition.released){reply(false,"navigation");return true;}
  if(Number(p.sampleAgeMs)>2500){reply(false,"expired");return true;}
  if(event==="resync"){publishPlayback(s.room,"resync",ws);return true;}
  const continuation=event!=="heartbeat" && s.lastIntentRevision===x.revision &&
    Number(p.baseRevision)===s.lastIntentBase && x.controller===s.clientId;
  // Duplicate pause/play state is idempotent: it must not manufacture a new
  // revision that invalidates an immediate legitimate Play from another tab.
  if((event==="pause"&&!x.playing)||(event==="play"&&x.playing&&!x.holds.size)){
    reply(true,"already-applied",event,true);return true;
  }
  // A fresh explicit, ordered Pause is a safe stop even if a competing rate
  // or playback commit overtook its base revision. Never undo that user's
  // stop by answering with a playing snapshot. Legacy/stale snapshots do
  // not get this exception; Play still requires causal revision. Fresh seeks
  // use the ordered, freshness-gated intent exception immediately below.
  const explicitPause=event==="pause"&&typeof p.commandId==="string"&&p.commandId.length>0;
  // A fresh, ordered seek is a new user intent, not a stale room snapshot.
  // It may arrive after another viewer changed the revision while this user
  // was dragging the timeline. Server receive order + per-client syncSeq +
  // sampleAgeMs provide the arbitration; delayed/reordered samples still fail.
  const explicitSeek=event==="seeked"&&typeof p.commandId==="string"&&p.commandId.length>0&&
    Number.isFinite(seq)&&Number.isFinite(Number(p.time))&&Number(p.time)>=0&&
    Number.isFinite(Number(p.sampleAgeMs))&&Number(p.sampleAgeMs)>=0&&Number(p.sampleAgeMs)<=2500;
  if(Number.isFinite(Number(p.baseRevision))&&Number(p.baseRevision)<x.revision&&!continuation&&!explicitPause&&!explicitSeek){
    reply(false,"stale-revision");return true;
  }
  if(!x.initialized&&Number.isFinite(p.time)&&p.time>=0){
    x.time=p.time;x.at=playbackClock();x.initialized=true;x.controller=s.clientId;x.controllerAt=playbackClock();
    if (transition?.released && !x.holds.size) x.playing=p.playing===true;
  }
  if(event==="heartbeat"){
    if(!x.controller||playbackClock()-x.controllerAt>12000)x.controller=s.clientId;
    if(x.holds.size){publishPlayback(s.room,"hold",ws);return true;}
    if(s.clientId!==x.controller){
      if(p.playing===x.playing)publishPlayback(s.room,"heartbeat",null,s);
      else publishPlayback(s.room,"resync",ws);
      return true;
    }
    x.controllerAt=playbackClock();
    if(p.playing!==x.playing){publishPlayback(s.room,"resync",ws);return true;}
    const sample=Number(p.time);
    if(Number.isFinite(sample)&&Math.abs(sample-playbackPosition(x))<=1.25){
      x.time=Math.max(0,sample);x.at=playbackClock();
    }
    publishPlayback(s.room,"heartbeat",null,s);return true;
  }
  if(x.holds.size&&event!=="pause"){reply(false,"not-ready","hold");return true;}
  x.time=playbackPosition(x);x.at=playbackClock();
  if((event==="seeking"||event==="seeked")&&Number.isFinite(p.time)&&p.time>=0)x.time=p.time;
  if(event==="play")x.playing=true;
  if(event==="pause")x.playing=false;
  if(event==="ratechange"&&Number.isFinite(p.rate)&&p.rate>=0.25&&p.rate<=4)x.rate=p.rate;
  x.controller=s.clientId;x.controllerAt=playbackClock();
  s.lastIntentBase=Number.isFinite(Number(p.baseRevision))?Number(p.baseRevision):x.revision;
  x.revision++;s.lastIntentRevision=x.revision;
  reply(true,"applied",event,true);return true;
}
function retainEmptyRoom(room) {
  const x=playbackFor(room);if(x?.idleTimer)clearTimeout(x.idleTimer);
  const timer=setTimeout(()=>{
    if(rooms.get(room)?.size)return;
    clearRoomDepartures(room,false);
    rooms.delete(room);roomTargets.delete(room);navigationTransitions.delete(room);roomPlayback.delete(room);
  },RECENT_MEMBER_MS);
  timer.unref?.();if(x)x.idleTimer=timer;
}
function sendTransitionState(ws, t) {
  if (!t) return;
  send(ws, {
    type: "transition-state",
    active: true,
    transitionId: t.id,
    url: t.url,
    title: t.title,
    reason: t.reason,
    releaseAt: t.releaseAt || null,
    releaseDelayMs: t.releaseAt ? Math.max(0,t.releaseAt-Date.now()) : null,
    requiredCount: t.required.size,
    readyCount: t.ready.size
  });
}
function cleanupTransitionParticipant(room, clientId) {
  const t = activeTransition(room);
  if (!t || !clientId) return;
  const live = [...(rooms.get(room) || [])].some(ws => clients.get(ws)?.clientId === clientId);
  if (live) return;
  t.required.delete(clientId);
  t.ready.delete(clientId);
  t.participants.delete(clientId);
  broadcastPeers(room);
  maybeReleaseTransition(room);
  if (!t.required.size && (!rooms.get(room) || rooms.get(room).size === 0)) {
    navigationTransitions.delete(room);
    rooms.delete(room);
    roomTargets.delete(room);
  }
}
function maybeReleaseTransition(room) {
  const t = activeTransition(room);
  if (!t || t.released || !t.required.size) return;
  if (playbackFor(room)?.holds.size) return;
  for (const id of t.required) if (!t.ready.has(id)) return;
  t.released = true;
  t.releaseAt = Date.now() + 900;
  const playback=playbackFor(room);
  if(playback){
    playback.time=0;playback.at=playbackClock()+900;playback.initialized=true;
    playback.rate=1;playback.playing=true;playback.holds.clear();playback.revision++;
  }
  broadcast(room, { type: "message", payload: {
    kind: "transition-release",
    transitionId: t.id,
    url: t.url,
    releaseAt: t.releaseAt,
    releaseDelayMs: 900,
    time: 0
  }});
  const releaseRevision=playback?.revision;
  setTimeout(()=>{
    if(activeTransition(room)===t && t.released && playback?.playing &&
       !playback.holds.size && playback.revision===releaseRevision)publishPlayback(room,"play");
  },900).unref?.();
  setTimeout(() => {
    const current = activeTransition(room);
    if (current === t) navigationTransitions.delete(room);
  }, 5000).unref();
}
function startNavigationTransition(room, initiator, p) {
  const set = rooms.get(room); if (!set) return null;
  const url = normalizeUrl(p.url); if (!url) return null;
  const t = {
    id: `nav_${Date.now().toString(36)}_${randId()}`,
    url,
    title: String(p.title || ""),
    reason: String(p.reason || "url-change"),
    createdAt: Date.now(),
    expiresAt: Date.now() + NAV_TRANSITION_TTL_MS,
    releaseAt: null,
    released: false,
    required: new Set(),
    ready: new Set(),
    participants: new Map()
  };
  for (const ws of set) {
    const s = clients.get(ws); if (!s) continue;
    const id = s.clientId || s.id;
    t.required.add(id);
    t.participants.set(id, transitionPeerRecord(s));
  }
  // Always include the initiating connection even if an unusual client frame
  // was not in the room Set at the instant this packet was handled.
  if (initiator) {
    const s = clients.get(initiator);
    if (s) {
      const id = s.clientId || s.id;
      t.required.add(id);
      t.participants.set(id, transitionPeerRecord(s));
    }
  }
  t.required.forEach(id => t.ready.delete(id));
  const playback=playbackFor(room);
  if(playback){
    freezePlayback(playback);playback.time=0;playback.initialized=false;
    playback.holds.clear();playback.revision++;
  }
  navigationTransitions.set(room, t);
  roomTargets.set(room, url);
  const transitionPayload = {
    kind: "transition-start",
    transitionId: t.id,
    url: t.url,
    title: t.title,
    reason: t.reason,
    requiredCount: t.required.size,
    readyCount: 0
  };
  broadcast(room, { type: "message", payload: transitionPayload });
  return t;
}
function detachSocket(ws, announce = true, removeClient = true, explicit = false, publish = true) {
  const s = clients.get(ws);
  if (!s) return;
  const room = s.room;
  const name = s.profile?.name || "Someone";
  const t = activeTransition(room);
  const stableId = s.clientId || s.id;
  const gracefulNavigation = !!(t && t.required.has(stableId) && !explicit);
  if (room && rooms.has(room)) {
    rooms.get(room).delete(ws);
    if (gracefulNavigation && announce) startDeparture(room, stableId, s, true);
    if (explicit) {
      clearPendingDeparture(room,stableId);
      forgetMember(room,stableId);
      releasePlaybackHold(room,stableId);
      cleanupTransitionParticipant(room,stableId);
      if (publish) broadcastPeers(room);
      announceLeft(room,stableId,name);
      if (!rooms.get(room)?.size) retainEmptyRoom(room);
    } else if (rooms.get(room).size) {
      if (announce && !gracefulNavigation) {
        if (explicit) {
          clearPendingDeparture(room, stableId);
          if (publish) broadcastPeers(room);
          announceLeft(room, stableId, name);
        } else {
          startDeparture(room, stableId, s);
          if (publish) broadcastPeers(room);
        }
      } else {
        if (publish) broadcastPeers(room);
      }
    } else if (gracefulNavigation) {
      // Keep the room alive for the navigation handoff; the stable participant
      // remains represented by the transition snapshot until the grace window ends.
      if (publish) broadcastPeers(room);
      retainEmptyRoom(room);
    } else {
      // Last socket gone. If it was a drop (relay restart / everyone's network)
      // remember the members so their rejoin is not announced as a new arrival.
      if (announce) startDeparture(room,stableId,s);
      retainEmptyRoom(room);
    }
  }
  if (s.clientId && clientSockets.get(s.clientId) === ws) clientSockets.delete(s.clientId);
  s.room = null;
  if (removeClient) clients.delete(ws);
}

wss.on("connection", ws => {
  const id = randId();
  clients.set(ws, { id, clientId: null, room: null, pageKey: null, pageUrl: null, profile: null });
  ws.isAlive = true;
  ws.on("pong", () => { ws.isAlive = true; });
  send(ws, { type: "system", text: "SyncParty connected." });

  ws.on("message", raw => {
    let m; try { m = JSON.parse(raw); } catch { return; }
    const s = clients.get(ws); if (!s) return;

    // Application-level liveness probe. Lets a client detect its OWN half-open
    // socket quickly (browsers cannot see protocol-level pings).
    if (m.type === "ping") { send(ws, { type: "pong", t: m.t || Date.now() }); return; }

    if (m.type === "join") {
      const room = norm(m.room); if (room.length !== 6) return;
      const requestedId = String(m.clientId || "").trim().slice(0, 128);
      // Bind identity once per socket. Repeated join cannot leave an old map
      // entry or change the author of later presence/chat messages.
      if (s.clientId && requestedId && requestedId !== s.clientId) return;
      const clientId = s.clientId || requestedId || s.id;
      let replacedLiveSocket = false;
      const repeatedJoin = s.room === room;
      const navKnown = !!activeTransition(room)?.participants.has(clientId);

      // Replace any older live socket belonging to the same browser tab.
      if (clientId) {
        const old = clientSockets.get(clientId);
        if (old && old !== ws) {
          // Same tab, newer socket (reload / network handover): continuity, not a new arrival.
          replacedLiveSocket = clients.get(old)?.room === room;
          detachSocket(old,!replacedLiveSocket,true,!replacedLiveSocket,!replacedLiveSocket);
          try { old.close(4001, "replaced by newer tab connection"); } catch {}
        }
      }

      // A single socket cannot belong to multiple rooms.
      if (s.room && !repeatedJoin) detachSocket(ws,true,false,true);

      s.room = room;
      s.clientId = clientId || s.clientId || s.id;
      s.id = s.clientId || s.id;
      s.pageKey = String(m.pageKey || "");
      s.pageUrl = normalizeUrl(m.pageUrl);
      s.profile = sanitizeProfile(m.profile);
      s.highlightConsent = m.highlightConsent === true;
      s.syncProtocol = Number(m.syncProtocol) || 1;
      const playback = playbackFor(room,s.syncProtocol >= 2);
      if (playback) {
        if (playback.idleTimer) { clearTimeout(playback.idleTimer); playback.idleTimer = null; }
        if (!playback.initialized && !activeTransition(room) && Number.isFinite(m.playback?.time) && m.playback.time >= 0) {
          playback.time = m.playback.time;
          playback.rate = Math.min(4,Math.max(0.25,Number(m.playback.rate)||1));
          playback.at = playbackClock();
          playback.playing = !m.resume && m.playback.playing === true;
          playback.initialized = true;
          playback.controller = s.clientId;
          playback.controllerAt = playbackClock();
        }
      }
      clientSockets.set(s.clientId, ws);

      const existingTransition = activeTransition(room);
      if (!rooms.has(room)) rooms.set(room, new Set());
      const set = rooms.get(room);
      const wasEmpty = set.size === 0;
      if (!roomTargets.has(room) && s.pageUrl) roomTargets.set(room, s.pageUrl);
      set.add(ws);

      if (existingTransition && !repeatedJoin) {
        // A reconnecting tab must prove readiness again on its newly loaded page;
        // otherwise the old page's ready bit could release the barrier early.
        existingTransition.required.add(s.clientId);
        existingTransition.ready.delete(s.clientId);
        existingTransition.participants.set(s.clientId, transitionPeerRecord(s));
      }

      send(ws, { type: "you", id: s.id, clientId: s.clientId });
      send(ws, { type: "room-info", room, syncProtocol:playback?2:1, playback:playbackPacket(room,"resync"), targetUrl: roomTargets.get(room) || null, transition: existingTransition ? { active:true, transitionId:existingTransition.id, url:existingTransition.url, title:existingTransition.title, reason:existingTransition.reason, releaseAt:existingTransition.releaseAt || null, requiredCount:existingTransition.required.size, readyCount:existingTransition.ready.size } : null });
      if (existingTransition) sendTransitionState(ws, existingTransition);
      const returning = clearPendingDeparture(room, s.clientId);
      const knownMember = returning || replacedLiveSocket || repeatedJoin || navKnown || wasRecentMember(room,s.clientId) || m.resume === true;
      broadcastPeers(room);
      if (returning || (knownMember && !repeatedJoin)) broadcast(room, { type: "message", payload: { kind: "peer-connection", state: "back", id: s.clientId, name: s.profile.name, t: Date.now() } }, ws);
      // During an active navigation handoff, presence is continuous: do not emit
      // a generic joined-party chat line for a reconnecting/newly arrived socket.
      if (!wasEmpty && !knownMember) presenceNotice(room,s.clientId,s.profile.name,"joined",ws);
      if (playback && s.syncProtocol>=2 && !repeatedJoin && !existingTransition && m.playback?.ready !== true) {
        holdPlayback(room,s.clientId,"loading",s.profile.name);
      }
      if (playback && s.syncProtocol<2 && knownMember) releasePlaybackHold(room,s.clientId);
      if (playback && !repeatedJoin) publishPlayback(room,"resync",ws);
      return;
    }

    if (m.type === "message" && s.room === norm(m.room)) {
      const p = m.payload;
      if (!p || typeof p !== "object") return;

      const kind = String(p.kind || "");
      // Connection transitions are relay-owned, never peer-supplied.
      if (kind === "peer-connection") return;
      const roomWideKinds = new Set([
        "chat", "sticker", "typing", "presence", "profile",
        "messageReaction", "reaction", "buffering", "system", "navigate", "transition-ready", "scrapbook-watch-state", "highlight-consent", "highlight-seek"
      ]);
      if (!roomWideKinds.has(kind) && p.pageKey && s.pageKey && p.pageKey !== s.pageKey) return;
      if ((kind === "sync" || kind === "buffering") && handlePlaybackMessage(ws,s,p)) return;
      if (kind === "highlight-consent") {
        s.highlightConsent = p.enabled === true;
        broadcastPeers(s.room);
        return;
      }

      if (kind === "navigate") {
        const target = normalizeUrl(p.url);
        if (!target) return;
        const t = startNavigationTransition(s.room, ws, p);
        if (!t) return;
        s.pageUrl = target;
        s.pageKey = String(p.pageKey || s.pageKey || "");
        // The transition-start packet above establishes the barrier for every
        // participant. Keep the original navigate packet for URL routing/toast.
      }

      if (kind === "transition-ready") {
        const t = activeTransition(s.room);
        if (!t || !t.required.has(s.clientId)) return;
        if (p.transitionId && String(p.transitionId) !== String(t.id)) return;
        if (playbackFor(s.room)?.holds.get(s.clientId)?.reasons.has("autoplay")) {
          t.released=false;
          releasePlaybackHold(s.room,s.clientId,"autoplay");
        }
        t.ready.add(s.clientId);
        const liveProfile = sanitizeProfile(p);
        t.participants.set(s.clientId, liveProfile);
        broadcastPeers(s.room);
        maybeReleaseTransition(s.room);
        return;
      }

      const profile = sanitizeProfile(p);
      if (kind === "profile" || kind === "presence" || kind === "chat" || kind === "sticker") s.profile = profile;

      const outgoingPayload = {
        ...p,
        ...(kind === "chat" ? {
          // Author and consent are relay-owned. A client cannot claim another
          // participant's identity or opt-in state. The relay signs eligible
          // messages so a later Highlights API request cannot forge consent.
          authorId: s.clientId || s.id,
          authorAccountId: s.profile?.accountId || null,
          highlightConsent: s.highlightConsent === true,
          // Never disclose the playback position to the room unless the author
          // opted in, even if a modified client sends an unsolicited snapshot.
          mediaSnapshot: s.highlightConsent === true ? p.mediaSnapshot || null : null,
          // Relay receive time is authoritative for chat ordering.
          sentAt: Date.now(),
          highlightRoom: s.room
        } : {}),
        ...(kind === "system" ? {presenceEvent:undefined,eventId:undefined} : {}),
        transitionId: kind === "navigate" ? activeTransition(s.room)?.id : p.transitionId,
        url: kind === "navigate" ? normalizeUrl(p.url) : p.url,
        id: s.clientId || s.id,
        name: profile.name,
        avatar: profile.avatar,
        color: profile.color
      };
      if (kind === "chat" && outgoingPayload.highlightConsent) {
        outgoingPayload.highlightProof = signHighlightMessage(outgoingPayload);
      }
      const interactionKinds = new Set(["reaction", "messageReaction", "typing", "highlight-seek"]);
      if (interactionKinds.has(kind)) {
        // Consent and actor identity are relay-owned for timeline interactions,
        // just like they are for Highlight chat messages. Echo to the sender so
        // its active local capture receives the same signed event as everyone else.
        outgoingPayload.highlightConsent = s.highlightConsent === true;
        outgoingPayload.highlightRoom = s.room;
        outgoingPayload.actorAccountId = s.profile?.accountId || null;
        outgoingPayload.sentAt = Date.now();
        outgoingPayload.eventId = String(p.eventId || `hi_${randId()}`).slice(0, 128);
        outgoingPayload.highlightInteractionProof = outgoingPayload.highlightConsent
          ? signHighlightInteraction(outgoingPayload)
          : null;
      }
      const echoToSender = kind === "chat" || interactionKinds.has(kind);
      broadcast(s.room, { type: "message", payload: outgoingPayload }, echoToSender ? null : ws);

      if (kind === "profile" || kind === "presence") broadcastPeers(s.room);
      return;
    }

    if (m.type === "leave" && s.room === norm(m.room)) {
      detachSocket(ws, true, true, true);
      try { ws.close(1000, "left room"); } catch {}
      return;
    }
  });

  ws.on("close", () => {
    detachSocket(ws, true);
  });
});

setInterval(() => {
  for (const [room, t] of navigationTransitions) {
    if (Date.now() > t.expiresAt) {
      navigationTransitions.delete(room);
      if ((!rooms.get(room) || rooms.get(room).size === 0) && roomTargets.has(room)) {
        rooms.delete(room);
        roomTargets.delete(room);
      }
    }
  }
  for (const [key, at] of recentMembers) if (Date.now() - at > RECENT_MEMBER_MS) recentMembers.delete(key);
  for (const ws of wss.clients) {
    if (ws.isAlive === false) { ws.terminate(); continue; }
    ws.isAlive = false;
    ws.ping();
  }
}, Number(process.env.SP_HEARTBEAT_MS) || 10000).unref();

httpServer.listen(port, "0.0.0.0", () => console.log(`SyncParty relay listening at http://127.0.0.1:${port}`));
