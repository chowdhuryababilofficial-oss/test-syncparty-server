const TMDB_BASE = "https://api.themoviedb.org/3";
const IMAGE_BASE = "https://image.tmdb.org/t/p";
const cache = new Map();
const inflight = new Map();
const requestCache = new Map();
const requestInflight = new Map();
let activeRequests=0;
const requestWaiters=[];
const CACHE_MS = 12 * 60 * 60 * 1000;
const MAX_TITLE = 240;

function clean(v, max = MAX_TITLE) { return String(v ?? "").replace(/\s+/g, " ").trim().slice(0, max); }
function image(path, size = "w780") { return /^\/[a-zA-Z0-9_.-]+\.(?:jpg|jpeg|png|webp)$/i.test(String(path||'')) ? `${IMAGE_BASE}/${size}${path}` : null; }
function normTitle(s) { return clean(s).toLowerCase().replace(/[^a-z0-9]+/g, " ").trim(); }
function similarity(a, b) {
  const A = new Set(normTitle(a).split(" ").filter(Boolean));
  const B = new Set(normTitle(b).split(" ").filter(Boolean));
  if (!A.size || !B.size) return 0;
  let hit = 0; for (const x of A) if (B.has(x)) hit++;
  return hit / new Set([...A, ...B]).size;
}
function scoreFor(q, name, isSlug) {
  let s = similarity(q, name);
  if (isSlug) {
    const A = normTitle(q).split(" ").filter(Boolean);
    const B = new Set(normTitle(name).split(" ").filter(Boolean));
    if (A.length && A.join("").length >= 5 && A.every(t => B.has(t))) s = Math.max(s, 0.62);
  }
  return s;
}
function keyFor(q) { return JSON.stringify([q.title || q.canonicalTitle || "", q.type || "", q.year ?? null, q.season ?? null, q.episode ?? null, q.provider || "", q.providerId || "", q.episodeId || "", q.numberingSystem || "", q.absoluteEpisode ?? null]); }

async function tmdb(path) {
  const hit=requestCache.get(path);
  if(hit&&Date.now()<hit.until)return hit.value;
  if(requestInflight.has(path))return requestInflight.get(path);
  const work=limitedRequest(path).then(value=>{
    if(requestCache.size>=500)requestCache.delete(requestCache.keys().next().value);
    requestCache.set(path,{value,until:Date.now()+(value?CACHE_MS:60000)});return value;
  }).finally(()=>requestInflight.delete(path));
  requestInflight.set(path,work);return work;
}
async function limitedRequest(path){
  if(activeRequests>=4){
    if(requestWaiters.length>=100)return null;
    await new Promise(resolve=>requestWaiters.push(resolve));
  }else activeRequests++;
  try{return await tmdbRequest(path);}
  finally{if(requestWaiters.length)requestWaiters.shift()();else activeRequests--;}
}
async function tmdbRequest(path) {
  const token = process.env.TMDB_API_TOKEN || "";
  if (!token) return null;
  try {
    const r = await fetch(`${TMDB_BASE}${path}`, { signal:AbortSignal.timeout(5000),headers: { Authorization: `Bearer ${token}`, Accept: "application/json" } });
    if (!r.ok) { console.error("[SyncParty TMDB] request failed", r.status, String(path).split("?")[0]); return null; }
    return await r.json();
  } catch { return null; }
}

async function seasonCounts(id, numberOfSeasons, seasons) {
  const counts = {};
  // The TV details response normally already contains every season count.
  for(const s of Array.isArray(seasons)?seasons:[])
    if(Number(s.season_number)>0&&Number.isInteger(s.episode_count)&&s.episode_count>=0)counts[s.season_number]=s.episode_count;
  if(Object.keys(counts).length)return counts;
  const deadline=Date.now()+6000;
  for (let n = 1; n <= Math.min(Number(numberOfSeasons) || 0, 40)&&Date.now()<deadline; n+=3) {
    await Promise.all(Array.from({length:Math.min(3,Math.min(Number(numberOfSeasons)||0,40)-n+1)},async(_,i)=>{
      const data=await tmdb(`/tv/${id}/season/${n+i}`);
      if(data&&Array.isArray(data.episodes))counts[n+i]=data.episodes.filter(e=>Number(e?.episode_number)>0).length;
    }));
  }
  return counts;
}

// Turn any page-derived string into a searchable TITLE: drop season/episode
// wording, year, quality tags and brand-style suffixes so "Lanterns - Season 1
// Episode 1" queries TMDB as "Lanterns". Similarity scoring needs the bare
// title; the noisy form scored 0.25 against the correct show and was rejected.
function cleanQuery(v) {
  let t = clean(v, MAX_TITLE);
  t = t.replace(/\bS\d{1,2}\s*[x\-]?\s*E\d{1,3}\b/ig, " ")
    .replace(/\bseason\s*\d+\b/ig, " ").replace(/\bepisode\s*\d+\b/ig, " ").replace(/\bep\.?\s*\d+\b/ig, " ")
    .replace(/\((?:19|20)\d{2}\)/g, " ").replace(/\s(?:19|20)\d{2}$/, " ").replace(/\b(?:full movie|full film|watch online|watch free|online free|free online|hd|1080p|720p)\b/ig, " ")
    .replace(/\s*[|\u2022]\s*.*$/, " ");
  t = t.replace(/\s+[-\u2013\u2014]\s*$/g, " ").replace(/^\s*[-\u2013\u2014]\s+/g, " ");
  return clean(t.replace(/\s+[-\u2013\u2014]\s+(?=$)/, " "));
}
function slugQueries(pathname) {
  const out = [];
  try {
    for (const seg of String(pathname || "").split("/").filter(Boolean).reverse()) {
      const words = decodeURIComponent(seg).replace(/\.(?:html?|php|aspx?)$/i, "").replace(/[_+.-]+/g, " ");
      if (words.replace(/[^a-z]/gi, "").length < 3) continue;
      if (/^(?:watch|video|player|embed|stream|episode|ep|season|tv|movie|movies|series|anime|home|play|shows?|films?)$/i.test(words.trim())) continue;
      out.push(words);
    }
  } catch {}
  return out;
}
function queryCandidates(provisional, meta) {
  // Prefer the actual series title. Generic player labels ("Episode", "Episode
  // 3", "Watch") are never provider search terms and must not beat it.
  const raw = [meta.seriesTitle, provisional.canonicalTitle, provisional.title, meta.title,
    ...(Array.isArray(meta.titleCandidates) ? meta.titleCandidates : []), ...slugQueries(meta.pathname)];
  const seen = new Set(); const out = []; const slugSet = new Set();
  const slugKeys = new Set(slugQueries(meta.pathname).map(x => normTitle(cleanQuery(x))));
  const expanded = [];
  for (const r of raw) {
    expanded.push(r);
    // "Resident Evil: Afterlife - Cinejoy": the server cannot know every site's
    // brand, so also try each side of a separator as its own title query.
    const parts = String(r || "").split(/\s+[-\u2013\u2014|]\s+/);
    if (parts.length > 1) expanded.push(...parts);
  }
  for (const r of expanded) {
    const q = cleanQuery(r);
    const k = normTitle(q);
    if (!q || q.length < 3 || /^(?:episode(?:\s*\d+)?|watch|video|player|stream|untitled)$/i.test(q) || !k || seen.has(k)) continue;
    seen.add(k); out.push(q);
    if (slugKeys.has(k)) slugSet.add(q);
    if (out.length >= 8) break;
  }
  out.slug = slugSet;
  return out;
}

async function resolveUncached(input = {}) {
  const meta = input.meta || {};
  const provisional = input.provisional || {};
  const sHint = provisional.season ?? meta.season;
  const eHint = provisional.episode ?? meta.episode;
  const yearHint = Number(provisional.metadataYear ?? meta.metadataYear ?? meta.seriesYear) || null;
  const queries = queryCandidates(provisional, meta);
  const knownProvider=String(provisional.metadataProvider || meta.metadataProvider || "").toLowerCase();
  const knownProviderId=String(provisional.metadataId || meta.metadataId || "");
  // This resolver only speaks TMDB. Never overwrite another provider's
  // authoritative identifier with a title-only TMDB guess.
  if (knownProvider && knownProvider !== "tmdb") return null;
  if (!queries.length && !(knownProvider === "tmdb" && /^[1-9]\d*$/.test(knownProviderId))) return null;
  let rawTitle = queries[0] || "";
  const key = keyFor({ title: queries.join("|"), type: provisional.contentType || meta.contentType, year: yearHint, season: sHint, episode: eHint, provider:knownProvider, providerId:knownProviderId, episodeId:meta.episodeMetadataId || provisional.episodeMetadataId, numberingSystem:meta.episodeNumberingSystem || provisional.episodeNumberingSystem, absoluteEpisode:meta.absoluteEpisodeNumber || provisional.absoluteEpisodeNumber });
  const hit = cache.get(key); if (hit && Date.now() - hit.at < CACHE_MS) return hit.value;

  // When the classifier had no title to work with (identity only in slug /
  // candidates) it also has no content type; the page's own anime hints still
  // decide Series vs Anime.
  const animeHint = /\/anime(?:\/|$)/i.test(String(meta.pathname || "")) || (Array.isArray(meta.typeHints) ? meta.typeHints : []).some(h => /^anime$/i.test(String(h)));
  const wantsAnime = provisional.contentType === "anime" || (!provisional.contentType && animeHint);
  const preferred = wantsAnime ? "tv" : provisional.contentType;
  const seasonHintValid=sHint != null && sHint !== "" && Number.isInteger(Number(sHint)) && Number(sHint) >= 0;
  const episodeHintValid=eHint != null && eHint !== "" && Number.isInteger(Number(eHint)) && Number(eHint) > 0;
  const typeHints=Array.isArray(meta.typeHints)?meta.typeHints.map(x=>String(x).toLowerCase()):[];
  const seriesEvidence=!!String(meta.seriesTitle||"").trim() || seasonHintValid&&episodeHintValid || typeHints.some(x=>/tvseries|tvepisode|series/.test(x));
  const isEpisode = episodeHintValid || seasonHintValid;
  let selected = null;
  let contentType = null;
  let preloadedDetails = null;
  // A known TMDB series id is authoritative. Resolve it directly rather than
  // searching by a possibly generic or localized page title.
  if (knownProvider === "tmdb" && /^[1-9]\d*$/.test(knownProviderId)) {
    let knownType=provisional.contentType || meta.contentType;
    knownType=knownType==='anime'?'series':knownType;
    if (knownType==='series') knownType='tv';
    if (knownType!=='movie' && knownType!=='tv') knownType=seriesEvidence?'tv':null;
    if (knownType) {
      preloadedDetails=await tmdb(`/${knownType}/${knownProviderId}?language=en-US`);
      if (preloadedDetails && String(preloadedDetails.id)===knownProviderId) {
        selected={id:knownProviderId};
        contentType=knownType==='tv'?(wantsAnime?'anime':'series'):'movie';
      }
    }
  }
  // The page may expose the real title in ANY of several fields (h1, JSON-LD,
  // slug, player title). Try each cleaned query in priority order and stop at
  // the first confident TMDB match, instead of betting on a single field.
  for (const q of (selected ? [] : queries)) {
    const [movieData,tvData]=await Promise.all([
      preferred === "tv" ? null : tmdb(`/search/movie?query=${encodeURIComponent(q)}&include_adult=false&language=en-US&page=1`),
      preferred === "movie" ? null : tmdb(`/search/tv?query=${encodeURIComponent(q)}&include_adult=false&language=en-US&page=1`)]);
    const movie = movieData?.results?.map(x => ({ ...x, _score: scoreFor(q, x.title || x.original_title, queries.slug.has(q)) + (x.release_date ? 0.02 : 0) })).sort((a,b) => b._score-a._score)[0] || null;
    const tvRows = (tvData?.results || []).map(x => {
      const candidateYear = Number(String(x.first_air_date || '').slice(0,4)) || null;
      const exactTitle = [x.name, x.original_name].some(v => v && normTitle(v) === normTitle(q));
      let score = scoreFor(q, x.name || x.original_name, queries.slug.has(q)) + (candidateYear ? 0.02 : 0);
      if (yearHint && candidateYear === yearHint) score += 0.18;
      else if (yearHint && candidateYear && candidateYear !== yearHint) score = -1;
      return { ...x, _score: score, _candidateYear: candidateYear, _exactTitle: exactTitle };
    }).sort((a,b) => b._score-a._score);
    // Do not guess between same-named remakes. With a year hint, only a
    // matching first-air year is eligible; without one, require one exact-name
    // result. Ambiguous/fuzzy matches remain unresolved and the watch can
    // still be saved under a provisional identity.
    const exactTvRows = tvRows.filter(x => x._exactTitle && (!yearHint || x._candidateYear === yearHint));
    const tv = exactTvRows.length === 1 ? exactTvRows[0] : (!yearHint && exactTvRows.length > 1 ? null : (yearHint ? null : (tvRows[0]?._score >= 0.85 ? tvRows[0] : null)));
    if (preferred === "movie" && movie && movie._score >= 0.45) { selected = movie; contentType = "movie"; }
    else if ((preferred === "series" || preferred === "anime" || isEpisode) && tv && tv._score >= 0.45) { selected = tv; contentType = wantsAnime ? "anime" : "series"; }
    else if (tv && tv._score >= 0.62 && (!movie || tv._score >= movie._score)) { selected = tv; contentType = wantsAnime ? "anime" : "series"; }
    else if (movie && movie._score >= 0.62) { selected = movie; contentType = "movie"; }
    if (selected && contentType) { rawTitle = q; break; }
  }
  if (!selected || !contentType) return null;

  let details = preloadedDetails || null;
  let seriesEpisodeCounts = null;
  let storyTotalEpisodes = 0;
  let storyEpisodesCompleted = 0;
  let storyProgress = null;
  let storyProgressConfidence = null;
  if (contentType === "movie") {
    if (!details) details = await tmdb(`/movie/${selected.id}?language=en-US`);
  } else {
    if (!details) details = await tmdb(`/tv/${selected.id}?language=en-US`);
    if (details?.number_of_seasons) {
      seriesEpisodeCounts = await seasonCounts(selected.id, details.number_of_seasons,details.seasons);
      storyTotalEpisodes = Object.values(seriesEpisodeCounts).reduce((a,b)=>a+b,0);
      if (storyTotalEpisodes > 0) storyProgressConfidence = Object.keys(seriesEpisodeCounts).length >= Math.min(details.number_of_seasons, 3) ? 0.92 : 0.75;
      // Do not infer that earlier episodes were watched merely because the
      // current URL is S2E3. The page layer combines the user's actual saved
      // episode history with this reliable total to calculate story progress.
    }
  }

  // Episode name, only when we have a confident series match AND a real
  // season+episode. TMDB is authoritative here, so this is the most reliable
  // episode-title source we have; a miss simply leaves it null and the UI
  // falls back to "Episode N" rather than guessing from the page title.
  let episodeTitle = null, episodeMetadataId = null, episodeRuntimeSec = null;
  if (contentType !== "movie") {
    const sNum = seasonHintValid ? Number(sHint) : null;
    const eNum = episodeHintValid ? Number(eHint) : null;
    if (sNum != null && eNum != null) {
      const ep = await tmdb(`/tv/${selected.id}/season/${sNum}/episode/${eNum}?language=en-US`);
      const epName = clean(ep?.name || "");
      // A provider episode id is stronger than episode title + coordinates.
      if (ep?.id != null) episodeMetadataId=String(ep.id);
      if (ep?.runtime != null && Number(ep.runtime)>0) episodeRuntimeSec=Math.round(Number(ep.runtime)*60);
      // TMDB returns generic placeholders when it lacks a real episode title.
      if (epName && !/^episode(?:\s*\d+)?$/i.test(epName)) episodeTitle = epName;
    }
  }

  const artworkCandidates = [
    image(details?.poster_path || selected.poster_path, "w780"),
    image(details?.backdrop_path || selected.backdrop_path, "w1280"),
    ...((meta.imageCandidates || []).filter(Boolean))
  ].filter(Boolean);
  const value = {
    eligible: true,
    metadataProvider: "tmdb",
    metadataId: String(selected.id),
    metadataYear: Number(String(details?.release_date || details?.first_air_date || "").slice(0,4)) || null,
    title: contentType === "movie" ? clean(details?.title || selected.title || rawTitle) : clean(details?.name || selected.name || rawTitle),
    canonicalTitle: contentType === "movie" ? clean(details?.title || selected.title || rawTitle) : clean(details?.name || selected.name || rawTitle),
    contentType,
    season: seasonHintValid ? Number(sHint) : null,
    episode: episodeHintValid ? Number(eHint) : null,
    episodeTitle,
    episodeMetadataProvider: episodeMetadataId ? "tmdb" : (meta.episodeMetadataProvider || provisional.episodeMetadataProvider || ""),
    episodeMetadataId: episodeMetadataId || meta.episodeMetadataId || provisional.episodeMetadataId || "",
    episodeNumberingSystem: meta.episodeNumberingSystem || provisional.episodeNumberingSystem || "",
    absoluteEpisodeNumber: Number.isInteger(Number(meta.absoluteEpisodeNumber ?? provisional.absoluteEpisodeNumber)) && Number(meta.absoluteEpisodeNumber ?? provisional.absoluteEpisodeNumber)>0 ? Number(meta.absoluteEpisodeNumber ?? provisional.absoluteEpisodeNumber) : null,
    episodeRuntimeSec,
    artwork: artworkCandidates[0] || null,
    backdrop: image(details?.backdrop_path || selected.backdrop_path, "w1280"),
    artworkCandidates: artworkCandidates.slice(0, 10),
    storyTotalEpisodes,
    storyEpisodesCompleted,
    storyProgress,
    storyProgressConfidence,
    seriesEpisodeCounts,
    totalRuntimeSec: contentType === "movie" && details?.runtime ? Number(details.runtime) * 60 : 0,
    externalUrl: `https://www.themoviedb.org/${contentType === "movie" ? "movie" : "tv"}/${selected.id}`,
    providerAttribution: "tmdb"
  };
  cache.set(key, { at: Date.now(), value });
  if(cache.size>300)cache.delete(cache.keys().next().value);
  return value;
}
function resolve(input={}) {
  const key=JSON.stringify(input);
  if(inflight.has(key))return inflight.get(key);
  const p=resolveUncached(input).finally(()=>inflight.delete(key));
  inflight.set(key,p);return p;
}
// Artwork recovery uses the saved identity and NEVER changes its source key,
// title, season or episode. Without a provider ID, require an exact title,
// unique match and matching year/type, rather than fuzzy repair of an old row.
async function recoverArtwork(entry={}) {
  const type=entry.contentType==='movie'?'movie':['series','anime'].includes(entry.contentType)?'tv':null;
  if(!type)return {artwork:null,backdrop:null};
  let id=entry.metadataProvider==='tmdb'&&/^[1-9]\d*$/.test(String(entry.metadataId||''))?String(entry.metadataId):null;
  if(!id){
    const rawTitle=clean(entry.canonicalTitle||entry.title),title=cleanQuery(rawTitle);
    const year=entry.metadataYear||Number(rawTitle.match(/\b((?:19|20)\d{2})\b/)?.[1])||null;
    if(!title||/^(?:untitled|video on|episode \d+)/i.test(title))return {artwork:null,backdrop:null};
    const data=await tmdb(`/search/${type}?query=${encodeURIComponent(title)}&include_adult=false&language=en-US&page=1`);
    if(!data)return {artwork:null,backdrop:null,transient:true};
    const hits=(data?.results||[]).filter(x=>
      [x.title,x.original_title,x.name,x.original_name].some(v=>v&&normTitle(v)===normTitle(title))&&
      (!year||Number(String(x.release_date||x.first_air_date||'').slice(0,4))===Number(year)));
    if(hits.length!==1)return {artwork:null,backdrop:null};
    id=String(hits[0].id);
  }
  const details=await tmdb(`/${type}/${id}?language=en-US`);
  if(!details)return {artwork:null,backdrop:null,transient:true};
  // Cards use the series poster/backdrop, not a fabricated episode portrait.
  // Confirm a numbered episode exists before attaching show assets to it.
  if(type==='tv'&&entry.season!=null&&entry.episode!=null){
    if(!(Number.isInteger(Number(entry.season))&&Number(entry.season)>=0&&Number(entry.episode)>0))return {artwork:null,backdrop:null};
    const ep=await tmdb(`/tv/${id}/season/${Number(entry.season)}/episode/${Number(entry.episode)}?language=en-US`);
    if(!ep)return {artwork:null,backdrop:null,transient:true};
  }
  return {artwork:image(details.poster_path),backdrop:image(details.backdrop_path,'w1280')};
}
module.exports = { resolve, recoverArtwork };
